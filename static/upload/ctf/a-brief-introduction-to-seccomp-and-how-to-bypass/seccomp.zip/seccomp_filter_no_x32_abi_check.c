// https://man7.org/linux/man-pages/man2/seccomp.2.html
#include <linux/seccomp.h>  /* Definition of SECCOMP_* constants */
#include <linux/filter.h>   /* Definition of struct sock_fprog */
#include <stdio.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stddef.h>
#include <fcntl.h>

// demo of filter mode, not allow open
int main() {
    char msg[] = "hello world1!\n";
    write(0,&msg,14);
    printf("current mode %d, change to filter mode now...\n", prctl(PR_GET_SECCOMP));

    // must set to PR_SET_NO_NEW_PRIVS to 1, otherwise SECCOMP_MODE_FILTER will fail.
    // https://man7.org/linux/man-pages/man2/seccomp.2.html
    prctl(PR_SET_NO_NEW_PRIVS,1,0,0,0);

    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD | BPF_W |BPF_ABS,(offsetof(struct seccomp_data, nr))), // get syscall number
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K,__NR_open,0,2), // if equal, continue (jump 0 instruction), else jump 2 instructions
        BPF_STMT(BPF_RET | BPF_K,SECCOMP_RET_KILL), // return kill
        BPF_STMT(BPF_RET | BPF_K,SECCOMP_RET_TRACE), // return trace
        BPF_STMT(BPF_RET | BPF_K,SECCOMP_RET_ALLOW), // return allow
    };
    // 
    struct sock_fprog prog = {
        .len = (unsigned short)(sizeof(filter)/sizeof(filter[0])),
        .filter = filter,                                         
    };

    printf("set mode return %d\n",prctl(PR_SET_SECCOMP,SECCOMP_MODE_FILTER,&prog));
    printf("seccomp change to mode filter\n");

    // open should not work
    int fd = syscall(__NR_open,"flag.txt",O_RDONLY);
    
    // rest of the program wont execute
    char flag[23];
    read(fd,&flag,23);
    write(1,&flag,23);
}