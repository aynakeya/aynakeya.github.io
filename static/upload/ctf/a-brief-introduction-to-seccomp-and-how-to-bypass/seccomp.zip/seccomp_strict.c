// https://man7.org/linux/man-pages/man2/seccomp.2.html
#include <stdio.h>
#include <sys/prctl.h>
#include <linux/seccomp.h>
#include <sys/syscall.h>
#include <unistd.h>

// /* Valid values for seccomp.mode and prctl(PR_SET_SECCOMP, <mode>) */
// #define SECCOMP_MODE_DISABLED	0 /* seccomp is not in use. */
// #define SECCOMP_MODE_STRICT	1 /* uses hard-coded filter. */
// #define SECCOMP_MODE_FILTER	2 /* uses user-supplied filter. */


// demo of strict mode, only allow read(), write(), sigreturn()
int main() {
    char msg[] = "hello world1!\n";
    write(0,&msg,14);
    printf("current mode %d, change to strict mode now...\n", prctl(PR_GET_SECCOMP));

    // two way of using prctl
    // prctl(PR_SET_SECCOMP,SECCOMP_MODE_STRICT);
    syscall(__NR_prctl,PR_SET_SECCOMP,SECCOMP_MODE_STRICT);
    
    // printf only use write, so it works
    printf("seccomp change to mode strict\n");
    // because prctl is a syscall. so no luck on that
    printf("This line shouldn't appear; current mode %d\n", prctl(PR_GET_SECCOMP));
}